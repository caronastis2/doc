angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('login', {
    url: '/page5',
    templateUrl: 'templates/login.html',
    controller: 'loginCtrl'
  })

  .state('signupCaroneiro', {
    url: '/page8',
    templateUrl: 'templates/signupCaroneiro.html',
    controller: 'signupCaroneiroCtrl'
  })

  .state('signupMotorista', {
    url: '/page9',
    templateUrl: 'templates/signupMotorista.html',
    controller: 'signupMotoristaCtrl'
  })

  .state('signupDecision', {
    url: '/page7',
    templateUrl: 'templates/signupDecision.html',
    controller: 'signupDecisionCtrl'
  })

  .state('pageMotorista', {
    url: '/page10',
    templateUrl: 'templates/pageMotorista.html',
    controller: 'pageMotoristaCtrl'
  })

  .state('pageCaroneiro', {
    url: '/page11',
    templateUrl: 'templates/pageCaroneiro.html',
    controller: 'pageCaroneiroCtrl'
  })

  .state('alterarCard', {
    url: '/page14',
    templateUrl: 'templates/alterarCard.html',
    controller: 'alterarCardCtrl'
  })

  .state('ratingMotorista', {
    url: '/page21',
    templateUrl: 'templates/ratingMotorista.html',
    controller: 'ratingMotoristaCtrl'
  })

  .state('alterarCardCaroneiro', {
    url: '/page17',
    templateUrl: 'templates/alterarCardCaroneiro.html',
    controller: 'alterarCardCaroneiroCtrl'
  })

  .state('contraOferta', {
    url: '/page15',
    templateUrl: 'templates/contraOferta.html',
    controller: 'contraOfertaCtrl'
  })

  .state('novaOferta', {
    url: '/page16',
    templateUrl: 'templates/novaOferta.html',
    controller: 'novaOfertaCtrl'
  })

  .state('meioDePagamento', {
    url: '/page12',
    templateUrl: 'templates/meioDePagamento.html',
    controller: 'meioDePagamentoCtrl'
  })

  .state('concluido', {
    url: '/page11',
    templateUrl: 'templates/concluido.html',
    controller: 'concluidoCtrl'
  })

  .state('realizarPagamento', {
    url: '/page18',
    templateUrl: 'templates/realizarPagamento.html',
    controller: 'realizarPagamentoCtrl'
  })

  .state('tiveUmProblema', {
    url: '/page22',
    templateUrl: 'templates/tiveUmProblema.html',
    controller: 'tiveUmProblemaCtrl'
  })

  .state('crDitoMotorista', {
    url: '/page19',
    templateUrl: 'templates/crDitoMotorista.html',
    controller: 'crDitoMotoristaCtrl'
  })

$urlRouterProvider.otherwise('/page5')


});